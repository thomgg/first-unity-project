﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidDestroy : MonoBehaviour
{
    public GameObject explodeAst, explodePlayer;
    public GameController gc;

    // Start is called before the first frame update
    void Start()
    {
        gc = FindObjectOfType<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        Instantiate(explodeAst, transform.position, Quaternion.identity);
       if (collision.gameObject.CompareTag("Bolt")) gc.addScore(1);

        if (collision.gameObject.CompareTag("Player"))
        {
            Instantiate(explodePlayer, collision.gameObject.transform.position, Quaternion.identity);
            collision.gameObject.SetActive(false);
        }
        else
        {
            Destroy(collision.gameObject);
        }


        Destroy(gameObject);

       
    }
}
