﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    const float DRAG = 0.2f;
    public float h_vel = 0, v_vel = 0;
    Rigidbody rb;
    public GameObject bolt_prefab, cannon1, boundary;
    float shot_cooldown = 0.5f, shot_timer;
    float bwidth, bheight;
    AudioSource cannon_sound;
    public AudioClip audioFire;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        shot_timer = Time.time;
        bwidth = boundary.transform.localScale.x;
        bheight = boundary.transform.localScale.z;
        cannon_sound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time - shot_timer > shot_cooldown && Input.GetButton("Fire"))
        {
            Instantiate(bolt_prefab, cannon1.transform.position, cannon1.transform.rotation);
            shot_timer = Time.time;
            cannon_sound.PlayOneShot(audioFire);
        }
    }

    void FixedUpdate()
    {
       

        h_vel += Input.GetAxis("Horizontal");
        v_vel += Input.GetAxis("Vertical");

        h_vel *= DRAG; v_vel *= DRAG;

        transform.position = new Vector3(Mathf.Clamp(transform.position.x + h_vel, -bwidth/2, bwidth/2), transform.position.y, Mathf.Clamp(transform.position.z + v_vel, -bheight/2, bheight / 2));
        transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(0, 0, Input.GetAxis("Horizontal") * -45), 0.5f);
    }
}
