﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidRotation : MonoBehaviour
{
    public GameObject player;
    public float vel;
    public Vector3 angularVelocity;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");

        Rigidbody rb = GetComponent<Rigidbody>();
        System.Random r = new System.Random();

        rb.velocity = (player.transform.position - transform.position).normalized * vel;
        rb.angularVelocity = new Vector3((float)(r.NextDouble() * 10 - 5), (float)(r.NextDouble() * 10 - 5), (float)(r.NextDouble() * 10 - 5));
        angularVelocity = rb.angularVelocity;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
