﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject boundary, AsteroidPrefab, player;
    float bound_w;
    System.Random r = new System.Random();
    public float spawn_delay, wave_delay;
    int score;
    public Text txtScore, txtGameOver, txtRestartMessage;
    bool game_over = false;

    // Start is called before the first frame update
    void Start()
    {
        bound_w = boundary.transform.localScale.x;
        StartCoroutine(SpawnWaves());
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        txtScore.text = "Score: " + score;
        if (!player.activeSelf)
        {
            if (!game_over)
            {
                txtGameOver.gameObject.SetActive(true);
                txtRestartMessage.gameObject.SetActive(true);
                game_over = true;
            }
            else if (Input.GetKey("r"))
            {
                game_over = false;
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }
    }

    IEnumerator SpawnWaves()
    {
        int wave_size = 5;
        while (!game_over)
        {
            yield return new WaitForSeconds(4); //wait for opening animation
            for (int i = 0; i < wave_size; i++)
            {
                Instantiate(AsteroidPrefab, new Vector3((float)(r.NextDouble() * bound_w - bound_w / 2), 0, boundary.transform.localScale.z / 2 + 2), Quaternion.identity);
                yield return new WaitForSeconds(spawn_delay);
            }
            wave_size++;
            yield return new WaitForSeconds(wave_delay);
        }
    }

    public void addScore(int added)
    {
        score += added;
    }
}
